FoodBook is an Online Food Ordering system for WordPress. It's an individual WooCommerce based Online Food Ordering WordPress plugin that allows you to easily add Food Ordering System to your WordPress Website. You can easily receive both PickUp and Delivery orders using FoodBook. There have user roles for Branch Manager, Kitchen Manager, and Delivery Man for managing orders and delivery without providing your WordPress admin access.

FoodBook has a user-friendly frontend with a live food search option and categories for filtering foods, a backend interface for shop/restaurant owner/admin, admin/dashboard interface for Branch Manager, Kitchen Manager and Delivery Man which will allow you to easily manage the orders and also comes with a pre-built user dashboard to manage their profile and orders.

This plugin automatically adds all of the required pages to your WordPress site when you activate the plugin. You will get the food items on your page using [foodbook-products] shortcode. This shortcode will work with all of the visual page builders like Elementor, WP Bakery page builder, Visual Composer, King Composer, Brave Builder, Guttenburg, etc. Anyone can easily update/edit this plugin by following our Well Sorted Online Documentation.

============================================================================
Online Documentation: https://themelooks.net/documentation/plugin/foodbook/
============================================================================

==========================================================================
Changelog included in "documentation/changelog" (folder).
==========================================================================


Installation:
==============
**The easy way.**

Download "mfolio"  and then extract the zip file and just drop the contents in the wp-content/plugins/ directory of your WordPress installation and then activate the Plugin from Plugins page.



Frequently Asked Questions:
============================
* Is this plugin compatable with the latest version of WordPress?
- Yes

* Is this plugin compatable with the latest version of WooCommerce?
- Yes


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts Used:

    Google Font - https://fonts.google.com
    Font Awesome - https://github.com/FortAwesome/Font-Awesome/

Frameworks / Libraries:

    jQuery - http://jquery.com
    Twitter Bootstrap - http://getbootstrap.com

Plugins Used:

    Magnific Popup - https://dimsemenov.com/plugins/magnific-popup/
    WayPoints - http://imakewebthings.com/waypoints/